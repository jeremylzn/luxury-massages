const Role = Object.freeze({
    1: 'Customer',
    2: 'Worker',
    3: 'Admin',
});

module.exports = Role